package com.example.mobilproje.model;

import java.util.List;

public class ParentModel {
    private String title;
    private List<YardimModel> yardimModelList;

    public ParentModel(String title, List<YardimModel> yardimModelList) {
        this.title = title;
        this.yardimModelList = yardimModelList;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public List<YardimModel> getYardimModelList() {
        return yardimModelList;
    }

    public void setYardimModelList(List<YardimModel> yardimModelList) {
        this.yardimModelList = yardimModelList;
    }
}
