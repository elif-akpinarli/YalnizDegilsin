package com.example.mobilproje.utils;

import android.content.Context;

public interface IUtils {
    void Toast(Context context, String message);
}
