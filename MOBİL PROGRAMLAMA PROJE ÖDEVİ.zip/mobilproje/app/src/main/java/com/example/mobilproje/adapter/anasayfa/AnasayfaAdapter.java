package com.example.mobilproje.adapter.anasayfa;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mobilproje.R;
import com.example.mobilproje.model.ParentModel;
import com.example.mobilproje.model.YardimModel;

import java.util.ArrayList;

public class AnasayfaAdapter extends RecyclerView.Adapter<AnasayfaAdapter.VH> {
    ArrayList<ParentModel> parentModelList;
    Context context;

    public AnasayfaAdapter(ArrayList<ParentModel> parentModelList, Context context) {
        this.parentModelList = parentModelList;
        this.context = context;
    }

    public static class VH extends RecyclerView.ViewHolder{
        TextView title;
        RecyclerView rv_child;

        public VH(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.tv_parent_title);
            rv_child = itemView.findViewById(R.id.rv_child);
        }
    }


    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.rv_parent_layout,parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH holder, int position) {
        ParentModel model = parentModelList.get(position);
        holder.title.setText(model.getTitle());

        //Child
        YardimlarAdapter yardimlarAdapter = new YardimlarAdapter((ArrayList<YardimModel>) model.getYardimModelList(), context);
        holder.rv_child.setLayoutManager(new LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false));
        holder.rv_child.setAdapter(yardimlarAdapter);
    }

    @Override
    public int getItemCount() {
        return parentModelList.size();
    }
}
