package com.example.mobilproje.model;

public class YardimModel {
    private int imgKurulus;
    private String kurulusAdi;

    private String kurulusURL;


    public YardimModel() {
    }

    public YardimModel(int imgKurulus, String kurulusAdi, String kurulusURL) {
        this.imgKurulus = imgKurulus;
        this.kurulusAdi = kurulusAdi;
        this.kurulusURL = kurulusURL;
    }

    public int getImgKurulus() {
        return imgKurulus;
    }

    public void setImgKurulus(int imgKurulus) {
        this.imgKurulus = imgKurulus;
    }

    public String getKurulusAdi() {
        return kurulusAdi;
    }

    public void setKurulusAdi(String kurulusAdi) {
        this.kurulusAdi = kurulusAdi;
    }

    public String getKurulusURL() {
        return kurulusURL;
    }

    public void setKurulusURL(String kurulusURL) {
        this.kurulusURL = kurulusURL;
    }
}
