package com.example.mobilproje.adapter.liste;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mobilproje.R;
import com.example.mobilproje.model.User;

import java.util.ArrayList;

public class DepremzedeAdapter extends RecyclerView.Adapter<DepremzedeAdapter.VH> {

    ArrayList<User> users;
    Context context;

    static ClickListener clickListener;

    public DepremzedeAdapter(ArrayList<User> users, Context context, ClickListener clickListener) {
        this.users = users;
        this.context = context;
        DepremzedeAdapter.clickListener = clickListener;
    }

    public DepremzedeAdapter(ArrayList<User> users, Context context) {
        this.users = users;
        this.context = context;
    }


    public static class VH extends RecyclerView.ViewHolder implements View.OnClickListener, View.OnLongClickListener{
        TextView olusturmaTarihi, adres, ad, unvanKendi, unvanYakini, durum;
        CardView card;

        public VH(@NonNull View itemView) {
            super(itemView);
            olusturmaTarihi = itemView.findViewById(R.id.olusturmaTarihi);
            adres = itemView.findViewById(R.id.adres);
            card = itemView.findViewById(R.id.card);
            ad = itemView.findViewById(R.id.ad);
            unvanKendi = itemView.findViewById(R.id.unvanKendi);
            unvanYakini = itemView.findViewById(R.id.unvanYakini);
            durum = itemView.findViewById(R.id.tvKurtarildi);


            //click
            itemView.setOnClickListener(this);
            itemView.setOnLongClickListener(this);
        }

        @Override
        public void onClick(View v) {
            int positionID = getAdapterPosition();
            v = card;
            if (positionID >= 0) {
                clickListener.onItemClick(v, positionID);
            }
        }

        @Override
        public boolean onLongClick(View v) {
            int position = getAdapterPosition();
            VH holder = new VH(v);
            v = card;
            if (position >= 0) {
                clickListener.onLongClick(v, holder ,position);
                return true;
            }
            return false;
        }
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v  = LayoutInflater.from(context).inflate(R.layout.item, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH holder, int position) {

        //Animation
        Animation anim = AnimationUtils.loadAnimation(holder.itemView.getContext(), android.R.anim.slide_in_left);

        User user = users.get(position);
        if(user.getAdresTarifi() == null){
            //Binding
            holder.olusturmaTarihi.setText(user.getOlusturulmaTarihi());
            holder.adres.setText(String.valueOf(user.getAdres()));
            holder.ad.setText(String.valueOf(user.getAd()));
            holder.unvanKendi.setVisibility(View.VISIBLE);
            holder.unvanYakini.setVisibility(View.GONE);

        }else{
            holder.olusturmaTarihi.setText(user.getOlusturulmaTarihi());
            holder.adres.setText(String.valueOf(user.getAdres()));
            holder.ad.setText(String.valueOf(user.getAd()));
            holder.unvanYakini.setVisibility(View.VISIBLE);
            holder.unvanKendi.setVisibility(View.GONE);

        }

        //start anim
        holder.itemView.startAnimation(anim);
    }

    //Interface
    public interface ClickListener {
        void onItemClick(View v, int position);
        void onLongClick(View v, VH holder, int position);
    }


    @Override
    public int getItemCount() {
        return users.size();
    }
}
