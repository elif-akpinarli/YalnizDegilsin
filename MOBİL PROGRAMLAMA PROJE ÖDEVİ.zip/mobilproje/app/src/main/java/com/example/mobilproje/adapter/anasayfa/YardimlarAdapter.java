package com.example.mobilproje.adapter.anasayfa;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mobilproje.R;
import com.example.mobilproje.model.YardimModel;

import java.util.ArrayList;

public class YardimlarAdapter extends RecyclerView.Adapter<YardimlarAdapter.VH> {

    ArrayList<YardimModel> yardimModelListesi;
    Context context;

    //Cons.
    public YardimlarAdapter(ArrayList<YardimModel> yardimModelListesi, Context context) {
        this.yardimModelListesi = yardimModelListesi;
        this.context = context;
    }

    //ViewHolder
    public static class VH extends RecyclerView.ViewHolder {
        ImageView imgKurulus;
        TextView kurulusAdi;
        CardView card;

        public VH(@NonNull View itemView) {
            super(itemView);
            imgKurulus = itemView.findViewById(R.id.kurulusImage);
            kurulusAdi = itemView.findViewById(R.id.kurulusAdi);
            card = itemView.findViewById(R.id.cardYardim);
        }
    }


        @NonNull
        @Override
        public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(context).inflate(R.layout.rv_child_layout, parent, false);
            return new VH(v);
        }

        @Override
        public void onBindViewHolder(@NonNull VH holder, int position) {
            YardimModel yardimModel = yardimModelListesi.get(position);
            holder.kurulusAdi.setText(yardimModel.getKurulusAdi());
            holder.imgKurulus.setImageResource(yardimModel.getImgKurulus());

            holder.card.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String url = yardimModel.getKurulusURL();
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData(Uri.parse(url));
                    context.startActivity(i);
                }
            });

        }

        @Override
        public int getItemCount() {
            return yardimModelListesi.size();
        }



}
