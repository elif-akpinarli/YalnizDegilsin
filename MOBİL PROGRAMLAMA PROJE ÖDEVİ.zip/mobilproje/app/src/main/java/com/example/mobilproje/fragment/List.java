package com.example.mobilproje.fragment;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.example.mobilproje.R;
import com.example.mobilproje.adapter.liste.DepremzedeAdapter;
import com.example.mobilproje.databinding.FragmentListBinding;
import com.example.mobilproje.model.User;
import com.example.mobilproje.utils.IUtils;

import java.util.ArrayList;

public class List extends Fragment implements IUtils {

    DatabaseReference mDatabaseReference, mKurtarilanlarReference;
    ArrayList<User> users;
    DepremzedeAdapter depremzedeAdapter;

    FragmentListBinding binding;

    public List() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //database ref
        mDatabaseReference = FirebaseDatabase.getInstance().getReference().child("Gocuk_Altindakiler");
        mKurtarilanlarReference = FirebaseDatabase.getInstance().getReference().child("Kurtarilanlar");
    }


    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = FragmentListBinding.inflate(inflater, container, false);
        users = new ArrayList<>();
        depremzedeAdapter = new DepremzedeAdapter(users, getContext(), new DepremzedeAdapter.ClickListener() {
            @Override
            public void onItemClick(View v, int position) {
                //Latitude ve Longtitude degerleri alma
                String lat = String.valueOf(users.get(position).getLat());
                String lon = String.valueOf(users.get(position).getLon());
                String adres = String.valueOf(users.get(position).getAdres());
                String adresTarifi = users.get(position).getAdresTarifi();
                if (adresTarifi == null && adres != null) {
                    //Navigasyona rota belirleme
                    Uri navigationIntentUri = Uri.parse("google.navigation:q=" + lat + "," + lon);//creating intent with latlng
                    Intent mapIntent = new Intent(Intent.ACTION_VIEW, navigationIntentUri);
                    mapIntent.setPackage("com.google.android.apps.maps");
                    requireContext().startActivity(mapIntent);
                }else{
                    Toast(getContext(), "Yakın adresi yönlendirilemiyor");
                }
            }

            //Long Click
            @Override
            public void onLongClick(View v, DepremzedeAdapter.VH holder, int position) {
                String id = users.get(position).getId();
                holder.itemView.setClickable(true);

                AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
                builder.setTitle("Emin misiniz?");
                builder.setMessage("Kurtulmanın gerçekleştiğinden emin misiniz?");
                builder.setPositiveButton("EVET", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        //TODO: Kurtarıldı ibaresi ekle.
                        User deleted = users.get(position);
                        deleted.setKurtarilmaDurumu(true);
                        holder.itemView.setClickable(false);
                        holder.itemView.findViewById(R.id.tvKurtarildi).setVisibility(View.VISIBLE);

                        //Gocuk Altindakiler bolumunden silinmesi
                        mDatabaseReference.child(id).removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if (task.isSuccessful()) {
                                    users.remove(users.get(position));
                                    depremzedeAdapter.notifyItemRemoved(position);
                                    depremzedeAdapter.notifyDataSetChanged();
                                }
                            }
                        });

                        //Verileri 'Kurtarilanlar' bolumune ekleme
                        User model = new User(deleted.getId(), deleted.getOlusturulmaTarihi(), deleted.getLon(), deleted.getLat(), deleted.getAdres(), deleted.getKisiSayisi(), deleted.getAd(), deleted.getTelefon(), deleted.getKurtarilmaDurumu());
                        mKurtarilanlarReference.child(id).setValue(model);
                        depremzedeAdapter.notifyDataSetChanged();
                    }
                });
                builder.setNegativeButton("HAYIR", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        // Toast(getContext(), "Vazgeçildi");
                        holder.itemView.setClickable(true);
                    }
                });
                AlertDialog alertDialog = builder.create();
                alertDialog.show();
                alertDialog.getButton(alertDialog.BUTTON_NEGATIVE).setTextColor(getResources().getColor(R.color.teal_200));
                alertDialog.getButton(alertDialog.BUTTON_POSITIVE).setTextColor(getResources().getColor(R.color.teal_200));
            }
        });
        binding.rvKalanlarListesi.setHasFixedSize(true);
        binding.rvKalanlarListesi.setLayoutManager(new LinearLayoutManager(getContext()));
        binding.rvKalanlarListesi.setAdapter(depremzedeAdapter);
        notesEventChangeListener();


        //return view
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }

    //Degisiklik izleme
    private void notesEventChangeListener() {
        binding.progressBar.setVisibility(View.VISIBLE);
        binding.tvLoading.setVisibility(View.VISIBLE);
        bosKontrolu();
        mDatabaseReference.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, String s) {
                User model = dataSnapshot.getValue(User.class);
                users.add(model);
                depremzedeAdapter.notifyItemInserted(users.size());
                binding.tvSize.setText("İhbar sayısı: " + users.size());
                depremzedeAdapter.notifyDataSetChanged();
                bosKontrolu();
            }


            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, String s) {
                //Update
                binding.tvSize.setText("İhbar sayısı: " + users.size());
                depremzedeAdapter.notifyDataSetChanged();
                bosKontrolu();

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {
                //Remove Control
                binding.tvSize.setText("İhbar sayısı: " + users.size());
                depremzedeAdapter.notifyDataSetChanged();
                Log.d("note size", String.valueOf(users.size()));
                bosKontrolu();

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, String s) {
                //Update Control
                binding.tvSize.setText("İhbar sayısı: " + users.size());
                depremzedeAdapter.notifyDataSetChanged();
                bosKontrolu();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast(getContext(), "Veritabanı hatası!");
                bosKontrolu();
            }
        });
    }

    //bos kontrolu
    private void bosKontrolu() {
        ValueEventListener postListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // Get NoteModel object
                User model = dataSnapshot.getValue(User.class);

                if (model != null) {
                    binding.progressBar.setVisibility(View.GONE);
                    binding.tvLoading.setVisibility(View.GONE);
                } else {
                    binding.notFound.setVisibility(View.VISIBLE);
                    binding.tvIhbarYok.setVisibility(View.VISIBLE);
                    binding.progressBar.setVisibility(View.INVISIBLE);
                    binding.tvLoading.setVisibility(View.INVISIBLE);
                    binding.tvSize.setText("İhbar sayısı: " + users.size());

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                //Handle-Error
            }

        };
        mDatabaseReference.addValueEventListener(postListener);

    }

    //TODO: Telefon doğrulaması yapılarak ihbarların
    // yalnızca ihbar açan kişi tarafından silinebilmesi sağlanacaktır.


    //Toast Method
    @Override
    public void Toast(Context context, String message) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
    }
}