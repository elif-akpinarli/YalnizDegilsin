package com.example.mobilproje.fragment;


import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Looper;
import android.preference.PreferenceManager;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.example.mobilproje.R;
import com.example.mobilproje.databinding.FragmentAlertBinding;
import com.example.mobilproje.model.User;
import com.example.mobilproje.utils.IUtils;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.Objects;

public class Alert extends Fragment implements IUtils {
    FusedLocationProviderClient mFusedLocationClient;
    Double lon, lat;
    FragmentAlertBinding binding;
    String adres;


    private static final int REQUEST_CODE = 44;
    int PERMISSION_ID = 44;

    public Alert() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(requireContext());
        // method to get the location
        getLastLocation();
    }
    //eof onCreate

    @SuppressLint("MissingPermission")
    private void getLastLocation() {
        // check if permissions are given
        if (checkPermissions()) {
            // check if location is enabled
            if (isLocationEnabled()) {
                mFusedLocationClient.getLastLocation().addOnCompleteListener(task -> {
                    Location location = task.getResult();
                    if (location == null) {
                        requestNewLocationData();
                        binding.btnPaylas.setEnabled(false);
                    } else {
                        lat = location.getLatitude();
                        lon = location.getLongitude();
                        adres = getCompleteAddressString(lat, lon);
                        binding.btnPaylas.setEnabled(true);
                    }
                });
            } else {
                Toast.makeText(getContext(), "Please turn on" + " your location...", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                startActivity(intent);
            }
        } else {
            // if permissions aren't available,
            // request for permissions
            requestPermissions();
        }
    }


    public String getCompleteAddressString(double LATITUDE, double LONGITUDE) {
        String strAdd = "";
        Geocoder geocoder = new Geocoder(getContext(), Locale.getDefault());
        try {
            java.util.List<Address> addresses = geocoder.getFromLocation(LATITUDE, LONGITUDE, 1);
            if (addresses != null) {
                Address returnedAddress = addresses.get(0);
                StringBuilder strReturnedAddress = new StringBuilder("");

                for (int i = 0; i <= returnedAddress.getMaxAddressLineIndex(); i++) {
                    strReturnedAddress.append(returnedAddress.getAddressLine(i)).append("\n");
                }
                strAdd = strReturnedAddress.toString();
                Log.w("My Current loction address", strAdd);
            } else {
                Toast(getContext(), "Konum alınamadı");
                Log.w("My Current loction address", "No Address returned!");
            }
        } catch (Exception e) {
            e.printStackTrace();
            Toast(getContext(), "Konum alınamadı");
            Log.e("My Current loction address", "Can't get Address!");
        }
        return strAdd;
    }

    @SuppressLint("MissingPermission")
    private void requestNewLocationData() {
        // Initializing LocationRequest
        // object with appropriate methods
        LocationRequest mLocationRequest = new LocationRequest();
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        mLocationRequest.setInterval(1000L);
        mLocationRequest.setFastestInterval(0);
        mLocationRequest.setNumUpdates(1);

        // setting LocationRequest
        // on FusedLocationClient
        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(requireContext());
        mFusedLocationClient.requestLocationUpdates(mLocationRequest, mLocationCallback, Looper.myLooper());
        adres = getCompleteAddressString(lat, lon);

    }

    private final LocationCallback mLocationCallback = new LocationCallback() {
        @Override
        public void onLocationResult(LocationResult locationResult) {
            Location mLastLocation = locationResult.getLastLocation();
            assert mLastLocation != null;
            lat = mLastLocation.getLatitude();
            lon = mLastLocation.getLongitude();
            adres = getCompleteAddressString(lat, lon);
        }
    };

    // method to check for permissions
    private boolean checkPermissions() {
        return ActivityCompat.checkSelfPermission(requireActivity(), Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    // method to request for permissions
    private void requestPermissions() {
        ActivityCompat.requestPermissions(requireActivity(), new String[]{
                Manifest.permission.ACCESS_COARSE_LOCATION,
                Manifest.permission.ACCESS_FINE_LOCATION}, PERMISSION_ID);
    }

    // method to check
    // if location is enabled
    private boolean isLocationEnabled() {
        LocationManager locationManager = (LocationManager) getContext().getSystemService(Context.LOCATION_SERVICE);
        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) || locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (REQUEST_CODE == PERMISSION_ID) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                //getCurrentLocation();
                getLastLocation();
            }
        }
    }

    //Permission Control
    @Override
    public void onResume() {
        super.onResume();
        if (checkPermissions()) {
            getLastLocation();
        }
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentAlertBinding.inflate(inflater, container, false);
        //return view
        return binding.getRoot();

    }


    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

    }

    @Override
    public void onStart() {
        super.onStart();
        // getLastLocation();
        binding.btnYakiniyim.setOnClickListener(v -> ((AppCompatActivity) getActivity()).getSupportFragmentManager().beginTransaction().replace(R.id.flFragment, new YakinAlert()).commit());
        binding.btnPaylas.setOnClickListener(v -> gocukAltindayimUyarisi());

        //Duduk (Whistle)
        final MediaPlayer mp = MediaPlayer.create(getContext(), R.raw.whistle);
        binding.btnDuduk.setOnClickListener(v -> {
            mp.start();
            //mp.setLooping(true);
            Toast(getContext(), "Düdük çalınıyor..");

        });
    }


    //Uyari
    public void gocukAltindayimUyarisi() {
        //TODO: Mesaj ile gonderme ozelligi
        //Veritabanına Canlı Kayıt Etme (Realtime Database)
        DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference()
                .child("Gocuk_Altindakiler");

        //Olusturma zamanini al.
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("dd MMMM yyyy HH:mm:ss", new Locale("tr"));
        String notOlusturmaTarihi = sdf.format(calendar.getTime());


        //Kisi sayisi
        String kisiSayisi = binding.txtKisiSayisi.getText().toString(); //zorunlu degil
        //Kisi ad
        String ad = Objects.requireNonNull(binding.txtAd.getText()).toString(); //zorunlu
        //Telefon
        String telefon = Objects.requireNonNull(binding.txtTelefon.getText()).toString(); //zorunlu
        //Aciklama
        // String adresAciklamasi = binding.txtAdres.getText().toString(); //zorunlu degil

        //Kontrol
        if (TextUtils.isEmpty(ad)) {
            Toast(getContext(), "Lütfen adınızı girin");
        } else if (TextUtils.isEmpty(telefon)) {
            Toast(getContext(), "Sana ulaşmamız için numaran gerekli");
        } else if (binding.txtTelefon.length() < 12) {
            Toast(getContext(), "Telefon numaran geçerli değil");
        } else {
            //Firebase Record
            if (kisiSayisi.isEmpty()) {
                kisiSayisi = "Bilinmiyor";
            }

            //Adres aciklamasi (Düşünülecek)
            if (adres.isEmpty()) {
                adres = getCompleteAddressString(lat, lon);
            }


            String id = mDatabase.push().getKey();
            assert id != null;
            Boolean durum = false;
            User user = new User(id, notOlusturmaTarihi, lon, lat, adres, kisiSayisi, ad, telefon, durum);
            mDatabase.child(id).setValue(user);

            //intent
            Log.e("log", id);
            SharedPreferences.Editor editor = PreferenceManager.getDefaultSharedPreferences(getContext()).edit();
            editor.putString("id", id);
            editor.apply();

            //Kayıt edildikten sonra icerigin temizlenmesi
            icerigiTemizle(binding.txtAd);
            icerigiTemizle(binding.txtKisiSayisi);
            icerigiTemizle(binding.txtTelefon);

            Toast(getContext(), "En kısa zamanda sana ulaşacağız.");
        }
    }


    private void icerigiTemizle(EditText icerik) {
        String deger = icerik.getText().toString();
        if (!deger.isEmpty()) {
            icerik.getText().clear();
        }
    }

    @Override
    public void Toast(Context context, String message) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
    }


}