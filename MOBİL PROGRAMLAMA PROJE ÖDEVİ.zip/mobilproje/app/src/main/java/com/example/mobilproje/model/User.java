package com.example.mobilproje.model;

public class User {
    private String id, olusturulmaTarihi, adres, ad, telefon, kisiSayisi, adresTarifi;
    private Double lon, lat;
    private Boolean kurtarilmaDurumu;




    public User() {
    }

    public User(String id, String olusturulmaTarihi, Double lon, Double lat, String adres, String kisiSayisi, String ad, String telefon , Boolean kurtarilmaDurumu) {
        this.id = id;
        this.olusturulmaTarihi = olusturulmaTarihi;
        this.lon = lon;
        this.lat = lat;
        this.adres = adres;
        this.kisiSayisi = kisiSayisi;
        this.ad = ad;
        this.telefon = telefon;
        this.kurtarilmaDurumu = kurtarilmaDurumu;
    }

    public User(String id, String olusturulmaTarihi, Double lon, Double lat, String adres, String kisiSayisi, String ad, String telefon, String adresTarifi, Boolean kurtarilmaDurumu) {
        this.id= id;
        this.olusturulmaTarihi = olusturulmaTarihi;
        this.lon = lon;
        this.lat = lat;
        this.adres = adres;
        this.kisiSayisi = kisiSayisi;
        this.ad = ad;
        this.telefon = telefon;
        this.adresTarifi = adresTarifi;
        this.kurtarilmaDurumu = kurtarilmaDurumu;
    }

    public Boolean getKurtarilmaDurumu() {
        return kurtarilmaDurumu;
    }

    public void setKurtarilmaDurumu(Boolean kurtarilmaDurumu) {
        this.kurtarilmaDurumu = kurtarilmaDurumu;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getAdresTarifi() {
        return adresTarifi;
    }

    public void setAdresTarifi(String adresTarifi) {
        this.adresTarifi = adresTarifi;
    }

    public String getAd() {
        return ad;
    }

    public void setAd(String ad) {
        this.ad = ad;
    }

    public String getTelefon() {
        return telefon;
    }

    public void setTelefon(String telefon) {
        this.telefon = telefon;
    }

    public String getKisiSayisi() {
        return kisiSayisi;
    }

    public void setKisiSayisi(String kisiSayisi) {
        this.kisiSayisi = kisiSayisi;
    }

    public String getAdres() {
        return adres;
    }

    public void setAdres(String adres) {
        this.adres = adres;
    }

    public String getOlusturulmaTarihi() {
        return olusturulmaTarihi;
    }

    public void setOlusturulmaTarihi(String olusturulmaTarihi) {
        this.olusturulmaTarihi = olusturulmaTarihi;
    }

    public Double getLon() {
        return lon;
    }

    public void setLon(Double lon) {
        this.lon = lon;
    }

    public Double getLat() {
        return lat;
    }

    public void setLat(Double lat) {
        this.lat = lat;
    }
}
