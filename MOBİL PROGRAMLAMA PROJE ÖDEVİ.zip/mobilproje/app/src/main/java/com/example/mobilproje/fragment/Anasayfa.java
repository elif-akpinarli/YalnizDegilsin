package com.example.mobilproje.fragment;

import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.viewpager.widget.ViewPager;

import com.example.mobilproje.R;
import com.example.mobilproje.adapter.anasayfa.AnasayfaAdapter;
import com.example.mobilproje.adapter.anasayfa.SliderAdapter;
import com.example.mobilproje.databinding.FragmentAnasayfaBinding;
import com.example.mobilproje.model.ParentModel;
import com.example.mobilproje.model.YardimModel;

import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

public class Anasayfa extends Fragment {
    ArrayList<ParentModel> parentModelArrayList;
    ArrayList<YardimModel> yardimlarModelList;
    ArrayList<YardimModel> filterModelList;
    AnasayfaAdapter anasayfaAdapter;
    FragmentAnasayfaBinding binding;

    //Slider
    ViewPager viewPager;
    //add images from drawable to array
    int[] images = {R.drawable.slider_banner, R.drawable.ahbap_banner, R.drawable.kizilay_banner};
    int currentPageCunter = 0;


    public Anasayfa() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = FragmentAnasayfaBinding.inflate(inflater, container, false);

        //init slider adapter
        binding.viewpager.setAdapter(new SliderAdapter(images, getContext()));

        //auto change image
        final Handler handler = new Handler();
        final Runnable update  = () -> {
            if (currentPageCunter == images.length){
                currentPageCunter = 0 ;
            }
            binding.viewpager.setCurrentItem(currentPageCunter++,true);
        };

        Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                handler.post(update);
            }
        },5000,3000);

        //init lists
        yardimlarModelList = new ArrayList<>();
        parentModelArrayList = new ArrayList<>();
        filterModelList = new ArrayList<>();

        //bind adapter
        anasayfaAdapter = new AnasayfaAdapter(parentModelArrayList, getContext());
        binding.rvParent.setHasFixedSize(true);
        binding.rvParent.setLayoutManager(new LinearLayoutManager(getContext()));
        binding.rvParent.setAdapter(anasayfaAdapter);

        //list filling
        yardimlarModelList.add(new YardimModel(R.drawable.bagis_yap, "Afad", "https://www.afad.gov.tr/"));
        yardimlarModelList.add(new YardimModel(R.drawable.ahbap, "Ahbap", "https://ahbap.org/"));
        yardimlarModelList.add(new YardimModel(R.drawable.kizilay, "Kızılay", "https://www.kizilay.org.tr/deprem2023/"));

        parentModelArrayList.add(new ParentModel("Bağış yap", yardimlarModelList));

        //list filling
        filterModelList.add(new YardimModel(R.drawable.deprem_io, "deprem.io", "https://deprem.io/"));
        filterModelList.add(new YardimModel(R.drawable.afet_harita, "afetharita.com", "https://afetharita.com/?lat=37.559776085222&lng=36.89758300781251&zoom=8"));
        filterModelList.add(new YardimModel(R.drawable.deprem_yardim, "depremyardim.com", "https://depremyardim.com/"));
        filterModelList.add(new YardimModel(R.drawable.afet_bilgi, "afetbilgi.com", "https://www.afetbilgi.com/"));

        parentModelArrayList.add(new ParentModel("Yararlı Linkler", filterModelList));

        //return view
        return binding.getRoot();
    }

    @Override
    public void onStart() {
        super.onStart();

    }
}